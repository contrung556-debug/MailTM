# Temp Mail OTP Test v1.0.4

Primary provider: Mail.tm. Fallback provider: Mail.gw.

## Changes from v1.0.1
- Retries transient HTTP 429/500/502/503/504 responses.
- Tries several active domains instead of one random domain.
- Falls back to Mail.gw when Mail.tm is unavailable.
- Returns the exact provider and failure stage (`domains`, `accounts`, `token`).
- Adds `GET /api/mailtm-health` to test both upstream providers.
- OTP and delete endpoints automatically use the provider that created the mailbox.

## Vercel root structure
- index.html
- vercel.json
- api/mailtm-create.js
- api/mailtm-otp.js
- api/mailtm-delete.js
- api/mailtm-health.js

Deploy the CONTENTS of this folder as the project root.


## v1.0.4
- Hiển thị password được tạo cùng email.
- Thêm Copy email, Copy password và Copy cả hai.

## v1.0.4
- Password cố định cho mọi email mới: `Cuong123@`.
- Giao diện tiếp tục hiển thị và cho phép copy email/password.

## v1.0.9
- Giữ nguyên 4 API v1.0.4 (create/otp/delete/health). Nếu API Vercel lỗi thì trình duyệt tự gọi trực tiếp Mail.tm/Mail.gw.
